--Write separate queries using a join, a subquery, a CTE, and then an EXISTS to list all AdventureWorks customers who have not placedan order.

use AdventureWorks2008R2


--using join
SELECT 
    c.CustomerID, c.PersonID, c.AccountNumber
FROM 
    Sales.Customer c
    LEFT JOIN Sales.SalesOrderHeader so ON c.CustomerID = so.CustomerID
WHERE 
    so.SalesOrderID IS NULL

--using subquery

SELECT c.CustomerID,c.PersonID, c.AccountNumber
FROM Sales.Customer c
WHERE c.CustomerID NOT IN (SELECT so.CustomerID FROM  Sales.SalesOrderHeader so )



--using cte

Go
WITH CustomersWithOrders AS (
    SELECT DISTINCT CustomerID
    FROM Sales.SalesOrderHeader
)
SELECT c.CustomerID,c.PersonID,c.AccountNumber
FROM Sales.Customer c LEFT JOIN CustomersWithOrders co ON c.CustomerID = co.CustomerID
WHERE co.CustomerID IS NULL;

--using exists

SELECT c.CustomerID,c.PersonID,c.AccountNumber
FROM Sales.Customer c
WHERE NOT EXISTS (
        SELECT so.CustomerID 
        FROM Sales.SalesOrderHeader so
        WHERE so.CustomerID = c.CustomerID
    )

