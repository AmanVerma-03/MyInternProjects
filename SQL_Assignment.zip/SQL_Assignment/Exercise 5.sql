--Write a Procedure supplying name information from the Person.Person table and accepting a filter for the first name. Alter the aboveStore Procedure to supply Default Values if user does not enter any value.

CREATE PROCEDURE person.Name_check 
@Name varchar(50)
AS
SELECT FirstName,MiddleName,LastName
FROM Person.Person
WHERE FirstName=@Name;
/*Modified*/
CREATE PROCEDURE
person.Name_chec
@Name varchar(50)= 'Default Name'
AS
SELECT FirstName,MiddleName,LastName
FROM Person.Person
WHERE FirstName=@Name;