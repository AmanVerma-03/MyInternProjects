--Create a function that takes as inputs a SalesOrderID, a Currency Code, and a date, and returns a table of all the SalesOrderDetail rowsfor that Sales Order including Quantity, ProductID, UnitPrice, and the unit price converted to the target currency based on the end offor the date provided. Exchange rates can be found in the Sales.CurrencyRate table
use AdventureWorks2008R2

GO
CREATE FUNCTION 
dbo.GetSalesOrderDetailsWithCurrency (
    @SalesOrderID INT,
    @CurrencyCode NVARCHAR(3),
    @ConversionDate DATE
)
RETURNS TABLE
AS
RETURN (
    SELECT 
        sod.OrderQty, 
        sod.ProductID, 
        sod.UnitPrice, 
        sod.UnitPrice * cr.AverageRate AS UnitPriceInTargetCurrency
    FROM 
        Sales.SalesOrderDetail sod
        JOIN Sales.SalesOrderHeader so ON sod.SalesOrderID = so.SalesOrderID
        JOIN Sales.CurrencyRate cr ON 
            cr.FromCurrencyCode = @CurrencyCode 
            AND cr.ToCurrencyCode = @CurrencyCode 
            AND cr.CurrencyRateDate = @ConversionDate
    WHERE 
        sod.SalesOrderID = @SalesOrderID
)