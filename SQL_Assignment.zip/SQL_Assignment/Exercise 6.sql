--Write a trigger for the Product table to ensure the list price can never be raised more than 15 Percent in a single change. Modify the above trigger to execute its check code only if the ListPrice column is updated
use AdventureWorks2008R2

GO
CREATE 
TRIGGER  trg_Product_ListPrice
ON Production.Product
AFTER UPDATE
AS
BEGIN
  DECLARE @MaxChange DECIMAL(10,2) = 1.15
  
  IF UPDATE(ListPrice)
  BEGIN
    IF EXISTS (
      SELECT *
      FROM inserted i
      JOIN deleted d ON i.ProductID = d.ProductID
      WHERE i.ListPrice > d.ListPrice * @MaxChange
    )
    BEGIN
      RAISERROR('List price can only be increased by a maximum of 15% in a single change.', 16, 1)
      ROLLBACK TRANSACTION
      RETURN
    END
  END
END
Go