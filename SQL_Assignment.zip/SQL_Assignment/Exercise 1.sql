use AdventureWorks2008R2
--1. Display the number of records in the [SalesPerson] table. (Schema(s) involved: Sales)
SELECT COUNT(BusinessEntityID) FROM sales.SalesPerson;

--2  Select both the FirstName and LastName of records from the Person table where the FirstName begins with the letter �B�.
SELECT FirstName,LastName
FROM Person.Person
WHERE FirstName like 'b%'
ORDER BY FirstName ASC;

--3   list of FirstName and LastName for employees where Title is one of Design Engineer, Tool Designer or Marketing Assistant
SELECT Person.Person.FirstName, Person.Person.LastName, HumanResources.Employee.JobTitle
FROM Person.Person INNER JOIN
 HumanResources.Employee ON Person.Person.BusinessEntityID = HumanResources.Employee.BusinessEntityID

 --4  Display the Name and Color of the Product with the maximum weight.
  SELECT Name,Color
  FROM Production.Product
  WHERE weight =(Select Max(weight) from Production.Product);

 --5 Display Description and MaxQty fields from the SpecialOffer table. Some of the MaxQty values are NULL, in this case display the value 0.00 instead
  SELECT Description ,ISNULL(MaxQty,0)
  FROM Sales.SpecialOffer

  --6 Display the overall Average of the [CurrencyRate].[AverageRate] values for the exchange rate �USD� to �GBP� for the year 2005
   SELECT AVG(AverageRate) AS AverageExchangefortheday
   FROM Sales.CurrencyRate 
   WHERE FromCurrencyCode = 'USD' AND ToCurrencyCode = 'GBP' AND YEAR(CurrencyRateDate)=2005;

   --7 Display the FirstName and LastName of records from the Person table where FirstName contains the letters �ss�. Display anadditional column with sequential numbers for each row returned beginning at integer 1
   SELECT ROW_NUMBER()
   OVER (ORDER BY Person.Person.FirstName) AS RowNumber, Person.Person.FirstName,Person.Person.LastName
   FROM Person.Person
   WHERE Person.Person.FirstName LIKE '%ss%';

   --8 Display the [SalesPersonID] with an additional column entitled �Commission Band� indicating the appropriate band as above
   SELECT BusinessEntityID,
  CASE
    WHEN CommissionPct = 0 THEN 'Band 0'
    WHEN CommissionPct <= 0.01 THEN 'Band 1'
    WHEN CommissionPct <= 0.015 THEN 'Band 2'
    ELSE 'Band 3'
  END AS [Commission Band]
FROM Sales.SalesPerson
ORDER BY BusinessEntityID;

  --9  Display the managerial hierarchy from Ruth Ellerbrock (person type � EM) up to CEO Ken Sanchez
  SELECT Person.Person.BusinessEntityID, Person.Person.FirstName, Person.Person.MiddleName, Person.Person.LastName, HumanResources.EmployeePayHistory.Rate,HumanResources.Employee.OrganizationLevel, HumanResources.Employee.JobTitle 
  FROM HumanResources.Employee INNER JOIN 
  HumanResources.EmployeePayHistory
  ON HumanResources.Employee.BusinessEntityID = HumanResources.EmployeePayHistory.BusinessEntityID INNER JOIN Person.Person ON HumanResources.Employee.BusinessEntityID = Person.Person.BusinessEntityID
  where Person.person.BusinessEntityID<49 
  order by Person.person.BusinessEntityID asc;

  --10 Display the ProductId of the product with the largest stock level. Hint: Use the Scalar-valued function [dbo].

 SELECT top 1 ProductID
FROM Production.ProductInventory
         order by Quantity desc;
