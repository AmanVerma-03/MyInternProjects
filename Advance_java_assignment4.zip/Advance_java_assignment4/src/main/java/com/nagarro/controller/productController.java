package com.nagarro.controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.dao.ProductDao;
import com.nagarro.model.Product;
import com.nagarro.utils.HibernateUtil;

@Controller
public class productController {
	
	private ProductDao pdDoa = new ProductDao(HibernateUtil.getSessionFactory());
	@RequestMapping("/productCatlog")
	public ModelAndView search(@RequestParam("color") String colour, @RequestParam("size") String size, @RequestParam("gender") String genderRecommendation,@RequestParam("preference") String outputPreference){
		ModelAndView mView = new ModelAndView();
		
		ProductDao.loadCSV(); // it loads csv file .........
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
        session.beginTransaction();
        String query = "SELECT p FROM Product p WHERE p.colour = :colour AND p.size = :size AND p.genderRecommendation = :gender AND p.availability = 'Y' ";
        if (outputPreference.equalsIgnoreCase("price")) {
            query += " ORDER BY price";
        } else if (outputPreference.equalsIgnoreCase("rating")) {
            query += " ORDER BY rating";
        } else if (outputPreference.equalsIgnoreCase("both")) {
            query += " ORDER BY price, rating";
        }
        List<Product> matchedResult = session.createQuery(query, Product.class).setParameter("colour", colour).setParameter("size", size)
        		.setParameter("gender", genderRecommendation).list();
        session.getTransaction().commit();
        session.close();
        mView.setViewName("productManage");
        mView.addObject("matchedProduct", matchedResult);
        return mView;
	}
}
