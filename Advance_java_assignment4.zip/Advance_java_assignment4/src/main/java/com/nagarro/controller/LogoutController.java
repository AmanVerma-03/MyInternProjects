package com.nagarro.controller;

import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nagarro.utils.HibernateUtil;

@Controller
public class LogoutController {
	
	@RequestMapping("/logout")
	public String logout() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
	    if (session != null) {
	        ((HttpSession) session).invalidate();
	    }
	    return "redirect:/login";
	}
}
