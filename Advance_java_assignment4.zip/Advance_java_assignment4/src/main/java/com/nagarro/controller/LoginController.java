package com.nagarro.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.dao.UserDao;
import com.nagarro.model.User;
import com.nagarro.utils.HibernateUtil;

@Controller
public class LoginController {
	
	private UserDao loginDao = new UserDao(HibernateUtil.getSessionFactory());;
	
	@RequestMapping("/login")
	public ModelAndView authenticate(@RequestParam("username") String username, @RequestParam("password") String password) {
		
		ModelAndView mView = new ModelAndView();
		
		if (loginDao.validate(username, password)!=null) {
            User c1 = loginDao.validate(username, password);
    		mView.setViewName("productManage");
    		mView.addObject("user",c1);	
        	return mView;
            
        } else {
        	mView.setViewName("index");
        	mView.addObject("user",null);
        	return mView;
        }
		
	}

}
