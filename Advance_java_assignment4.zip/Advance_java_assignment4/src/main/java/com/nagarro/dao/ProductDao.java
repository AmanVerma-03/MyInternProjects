package com.nagarro.dao;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.nagarro.model.Product;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

public class ProductDao {

	private static SessionFactory sessionFactory;

	public ProductDao(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
		
	}
	public static void loadCSV() {
		// Load CSV files 
		final String CSV_DIRECTORY ="C:\\Users\\amanverma03\\eclipse-workspace\\Advance_Java_Assignment4\\csvFiles";
        File[] csvFiles = new File(CSV_DIRECTORY).listFiles(file -> file.isFile() && file.getName().endsWith(".csv"));
        for (File filename : csvFiles) {
        	try (CSVReader reader = new CSVReader(new FileReader(filename))) {
                List<String[]> rows = reader.readAll();
        		boolean firstLine = true;
                for (String[] row : rows) {
                	if(firstLine) {
                		firstLine = false;
                		continue;
                	}
            	
                	Session session = sessionFactory.openSession();
                	session.beginTransaction();
                    Product product = new Product();
                 
                    product.setId(row[0]);
                    product.setName(row[1]);
                    product.setColour(row[2]);
                    product.setGenderRecommendation(row[3]);
                    product.setSize(row[4]);
                    product.setPrice(Double.parseDouble(row[5]));
                    product.setRating(Double.parseDouble(row[6]));
                    product.setAvailability(row[7]);
                    
                    System.out.print("It's Done");
                    session.saveOrUpdate(product);
                    session.getTransaction().commit();
                    session.close();
                           	               	
                    
                }
            } catch (IOException | CsvException e) {
                System.err.println("Error loading CSV file: " + filename);
                e.printStackTrace();
            }
        }
	}
	
}
