package com.nagarro.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.nagarro.model.User;
import com.nagarro.utils.HibernateUtil;

public class UserDao {
	private SessionFactory sessionFactory;

	public UserDao(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	
	
	public User validate(String userName, String password) {

        Transaction transaction = null;
        User cus = null;
        try  {
        	Session session = sessionFactory.openSession();
            transaction = session.beginTransaction();
            cus = (User) session.createQuery("FROM User u WHERE u.username = :userName").setParameter("userName", userName)
                .uniqueResult();
            if (cus != null && cus.getPassword().equals(password)) {
                return cus;
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return null;
    }

}
