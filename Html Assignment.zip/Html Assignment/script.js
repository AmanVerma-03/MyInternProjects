const studentTable = document.querySelector("tbody");

addEventListener("submit", (e) => {
    e.preventDefault();

    const studentName = document.querySelector("input[name='name']");
    const studentEmail = document.querySelector("input[name='email']");
    const studentWebsite = document.querySelector("input[name='website']");
    const studentGender = document.querySelectorAll("input[name='gender']");
    const studentSkills = document.querySelectorAll("input[name='skills']");
    const studentImage = document.querySelector("input[name='image']");
    
    const td1 = document.createElement('td');

    const name = document.createElement('p');
    name.append(`${studentName.value}`);

    const email = document.createElement('p');
    email.append(`${studentEmail.value}`);

    const website = document.createElement('a');
    website.setAttribute("href",`${studentWebsite.value}`);
    website.setAttribute("target","_blank")
    website.append(`${studentWebsite.value}`);

    const gender = document.createElement('p');
    const skills = document.createElement('p');
    
    if (studentGender[0].checked) {
        gender.append(`${studentGender[0].value}`);
    } else {
        gender.append(`${studentGender[1].value}`);
    }

    let skillAll = "";
    for (skill of studentSkills) {
        if (skill.checked) {
            if (skillAll === "") {
                skillAll += `${skill.value}`;
            } else {
                skillAll += ',' + `${skill.value}`;
            }
        }
    }
    skills.append(skillAll);
    
    td1.append(name);
    td1.append(gender);
    td1.append(email);
    td1.append(website);
    td1.append(skills)
    td1.setAttribute("class","td1")

    const td2 = document.createElement('td');

    const image = document.createElement('img');
    if(studentImage.value) {
        image.setAttribute("src",`${studentImage.value}`);
    } else {
        image.setAttribute("src",`photo.jpg`);
    }
    
    
    td2.append(image);
    td2.setAttribute("class","td2")

    const tr = document.createElement("tr");
    tr.append(td1);
    tr.append(td2);

    studentTable.append(tr);
});