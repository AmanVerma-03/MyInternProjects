//importing student model
const Student = require('../models/student');
Student.sync()
////entering student login page 
const Studententry = (req, res) => {
  res.render("student/student-login");
};
//////entering student result page 
const Studentview = async (req, res) => {
  const Srno = req.body.rollno;
  const Sdob = req.body.dob;
  try {
    const singleStudent = await Student.findOne(
      {
        where:
        { roll: Srno,
        dob: Sdob},
      }
      
      );
    if (!singleStudent) {
      res.render("student/student-login", {
        error: "Please enter correct roll number"
      });
    } else {
      console.log(singleStudent.dataValues);
      res.render("student/student-result", { student: singleStudent.dataValues });
    }
  } catch (error) {
    console.error("An error occurred:", error);
    res.send("error");
  }
};
module.exports = {
  Studententry,
  Studentview
};
