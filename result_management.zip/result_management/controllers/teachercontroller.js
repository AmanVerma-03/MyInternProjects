const Teacher = require('../models/Teacher');
const Student = require('../models/student');

const TeacherLoginForm = (req, res) => {
    res.render("teacher/teacher-login");
};

const TeacherLoginForm_Post = async (req, res) => {
    try {
        const teacher = await Teacher.findOne({
            where: {
                username: req.body.email,
                password: req.body.password
            }
        });

        if (teacher) {
            res.redirect("/teacher/teacher-choice");
        } else {
            res.render("teacher/teacher-choice", {
                error: "Please Enter Correct Username and Password"
            });
        }
    } catch (error) {
        console.error("An error occurred:", error);
        res.send(error);
    }
};

const viewrecords = async (req, res) => {
    try {
        const students = await Student.findAll({
            attributes: ['id', 'roll', 'name', 'dob', 'score']
        });

        const cleanedStudents = students.map(student => student.get({ plain: true }));
        console.log(cleanedStudents);
        res.render("teacher/view-records", { students: cleanedStudents });
    } catch (error) {
        console.error("An error occurred:", error);
        res.send(error);
    }
};

const editStudent = async (req, res) => {
    try {
        const student = await Student.findByPk(req.params.id);
        if (!student) {
            return res.status(404).send("Student not found");
        }
        res.render("teacher/edit-student", { student });
    } catch (error) {
        console.error("An error occurred:", error);
        res.status(500).send("Internal server error");
    }
};

const updateStudent = async (req, res) => {
    try {
        const student = await Student.findByPk(req.params.id);
        if (!student) {
            return res.status(404).send("Student not found");
        }

        // Update student data based on the form input
        student.name = req.body.name; // Assuming there's a 'name' field in the form

        // Save the updated student data
        await student.save();

        res.redirect(`/students/view-records`); // Redirect to the student's profile page
    } catch (error) {
        console.error("An error occurred:", error);
        res.status(500).send("Internal server error");
    }
};

module.exports = { editStudent, updateStudent };

const deleteStudent = async (req, res) => {
    try {
        await Student.destroy({
            where: { id: req.params.id }
        });
        res.redirect("/teacher/view-records");
    } catch (error) {
        console.error("An error occurred:", error);
        res.send(error);
    }
};

const Teacherchoice = (req, res) => {
    res.render("teacher/teacher-choice");
};

const AddStudent = (req, res) => {
    res.render("teacher/add-student");
};

const addStudent_post = async (req, res) => {
    const singleStudent = {
        name: req.body.name,
        roll: req.body.roll,
        dob: req.body.dob,
        score: req.body.score
    };
    try {
        await Student.create(singleStudent);
        res.redirect("/teacher/add-student");
    } catch (error) {
        console.error("An error occurred:", error);
        res.send(error);
    }
};

module.exports = {
    TeacherLoginForm,
    TeacherLoginForm_Post,
    viewrecords,
    editStudent,
    updateStudent,
    deleteStudent,
    Teacherchoice,
    AddStudent,
    addStudent_post
};
