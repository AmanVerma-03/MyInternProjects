const { Sequelize, DataTypes, Model } = require('sequelize');
const sequelize = new Sequelize('mysql://root:root@localhost:3306/studentmarks');

class Student extends Model {}

Student.init({
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  roll: {
    type: DataTypes.INTEGER,
    allowNull: false,
    unique: true
  },
  name: DataTypes.STRING,
  dob: DataTypes.DATEONLY,
  score: DataTypes.INTEGER
}, {
  sequelize,
  modelName: 'Student'
});

module.exports = Student;
