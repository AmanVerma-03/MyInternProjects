// Import required modules
const Sequelize = require('sequelize');
const express = require("express")
const handlebars = require('express-handlebars');
const bodyParser = require('body-parser');
const app = express();
const port = 3004;
const path = require('path');

//configuration
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


//using template engine
app.engine('hbs', handlebars.engine({
    extname: '.hbs',
    defaultLayout: 'main',
    layoutsDir: path.join(__dirname + '/views/layouts'),
    partialsDir: path.join(__dirname + '/views/partial')
}));

app.set("view engine", "hbs");
app.set("views", "./views");
app.use(express.static('public'))

// Initialize Sequelize and connect to the database
const sequelize = new Sequelize('studentmarks', 'root', 'root', {
  host: 'localhost',
  dialect: 'mysql'
});

// Test the database connection
sequelize.authenticate()
  .then(() => {
    console.log('Database connection has been established successfully.');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
  });



//teacher and student routes
const teachRoutes = require("./routes/teacherroutes")
const studRoutes = require("./routes/studentroutes")
app.use("/teacher",teachRoutes);
app.use("/student",studRoutes);

//routes
app.get("/", (req, res) => {
  res.render("login");
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});

// 404 page
app.use((req, res) => {
  res.status(404).render('404', { title: '404' });
});