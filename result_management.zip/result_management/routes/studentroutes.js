const express = require("express");
const router = express.Router();
const studentcontroller = require('../controllers/studentcontroller');
router.get('/login',studentcontroller.Studententry);
router.get('/view',(req,res)=>{
res.render('student/student-result');
})
router.post('/student-login',studentcontroller.Studentview);
module.exports=router;