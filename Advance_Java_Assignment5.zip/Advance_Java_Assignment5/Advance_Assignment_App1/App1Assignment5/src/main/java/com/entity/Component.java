package com.entity;

public @interface Component {

}
