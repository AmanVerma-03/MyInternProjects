import java.util.*;
class Insurance_type {
    static double Ins_type(double amt, String insurancetype, double price) {
        try {
            if (insurancetype.equals("premium"))
                return calculate.solve(amt, 0.20, price);
            else if (insurancetype.equals("basic"))
                return calculate.solve(amt, 1, price);
            else
                System.out.println("Please input correct Insurance type");
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }
}
class car{
    static double type(String cartype, double price , String insurancetype) {
        try {
            if (cartype.equals("hatchback")) {
                return Insurance_type.Ins_type(0.05, insurancetype, price);
            } else if (cartype.equals("suv")) {
                return Insurance_type.Ins_type(0.10, insurancetype, price);
            } else if (cartype.equals("sedan")) {
                return Insurance_type.Ins_type(0.08, insurancetype, price);
            } else {
                System.out.println("Please input correct car type");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }
}
class calculate{
    static double solve(double amt, double tax, double price){
        double result = 0.0;
        result = (amt * price) ;
        result += (result * tax) ;
        return result;
    }
}
class Insurance_amount{
    public static String model, cartype, insurancetype;
    public static double price;
    public static void main(String args[]){
        Scanner  obj = new Scanner(System.in);
        char ch;
        do{
            System.out.println("Enter car model");
            model = obj.nextLine();
            System.out.println("Enter car type");
            cartype = obj.nextLine();
            System.out.println("Enter car insurance type");
            insurancetype = obj.nextLine();
            System.out.println("Enter car price");
            price = obj.nextDouble();
            cartype = cartype.toLowerCase();
            insurancetype = insurancetype.toLowerCase();
            double amount = car.type(cartype,price,insurancetype);
            System.out.println("The Car model is " + model + "  " +"and Car type" + "  "+ cartype + "  " +"Insurance to be paid is" +"  "+amount);
            ch = ' ';
            while(ch != 'y' && ch != 'n')
            {
                try
                {
                    System.out.print("Wish to continue? (Y/N) ? ");
                    ch = obj.next().charAt(0);
                    ch = Character.toLowerCase(ch);

                    if(ch != 'y' && ch != 'n')
                    {
                        System.out.println(ch);
                        System.out.println("Please input correct character");
                    }
                }
                catch(Exception e)
                {
                    System.out.println(e);

                }
            }
        }while(ch != 'n');

    }
}