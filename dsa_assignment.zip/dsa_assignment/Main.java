import java.util.*;
class Linked_list

{
    static void func() {
        Scanner sc = new Scanner(System.in);
        LinkedList<String> ll = new LinkedList<>();
        char ch;
        do {
            System.out.println("""
                    Enter which operation you would be like to perform in linked list\s
                    A:Insert
                    B:Insert at Position
                    C:Delete
                    D:Delete at position
                    E:Centre
                    F:Sort
                    G:Reverse
                    H:Size
                    I:Iterator
                    J:Traverse/Print""");
             ch = sc.next().toUpperCase().charAt(0);
             char choice ;
            switch (ch) {
                case 'A' -> {
                    System.out.print("Enter data to be inserted : ");
                    int data = sc.nextInt();
                    ll.add(String.valueOf(data));
                    break ;
                }
                case 'B' -> {
                    System.out.print("Enter data : ");
                    int data1 = sc.nextInt();
                    System.out.print("Enter Position : ");
                    int position = sc.nextInt();
                    StringBuilder st = new StringBuilder();
                    StringBuffer st1 = new StringBuffer();
                    for (String integer : ll) {
                        st.append(integer).append(" ");
                    }
                    for (int i = 0; i < ll.size(); i++) {
                        st1.append(st.charAt(i));
                        if (i == position) {
                            st1.append(data1).append(" ");
                        }
                    }
                    System.out.println(st1);
                    break ;
                }
                case 'C' -> {
                    System.out.print("Enter data to be deleted : ");
                    ll.remove(ll.size());
                    System.out.println(ll);
                    break ;
                }
                case 'D' -> {
                    System.out.print("Enter Position to be deleted :");
                    int position = sc.nextInt();
                    ll.remove(position);
                    System.out.println(ll);
                    break ;
                }
                case 'E' -> {
                    System.out.print("The middle node of the linked element is ");
                    StringBuilder st = new StringBuilder();
                    for (String integer : ll) {
                        st.append(integer).append(" ");
                    }
                    System.out.println(st.charAt(ll.size() / 2));
                    break ;
                }
                case 'F' -> {

                    System.out.println("The Size of Linked List is : " + ll.size());
                    break ;
                }
                case 'H' -> {

                    Collections.sort(ll);
                    System.out.println("The Sorted linked list is : \n" + ll);
                    break ;
                }
                case 'G' -> {

                    Collections.reverse(ll);
                    System.out.println("The Reversed Linked_list is here as follows : \n " + ll);
                    break ;
                }
                case 'I' -> {
                    System.out.println("The iterated list is here as follows :");
                    for (String s : ll) {
                        System.out.println(s);
                    }
                    break ;
                }
                case 'J' -> {
                    System.out.println("The traverse linked list is here as follows ");
                    for (String listElement : ll) {
                        System.out.print(listElement + " ");
                    }
                    break ;
                }
                default -> System.out.println("Input a valid choice");
            }
            choice = ' ';
            while(choice != 'Y' && choice != 'N')
            {
                System.out.print("Wish to continue? (Y/N) ? ");
                choice = sc.next().toUpperCase().charAt(0);

                if(choice != 'Y' && choice != 'N')
                {
                    System.out.println("Please input a valid character");
                }
            }
        }while (ch != 'N') ;


    }
}

class Hash_table{
    static void func(){
        Scanner sc = new Scanner(System.in);
        Hashtable<String, Integer> hashtable = new Hashtable<>();
        char choice ;
        do {
            System.out.println("""
                    Enter which operation you would like to perform in hashtable
                    A:Insert
                    B:Delete
                    C:Contains a value
                    D:Get value by key
                    E:Iterator
                    F:Size
                    G:Traverse\\Print
                    """);
            char ch = sc.next().toUpperCase().charAt(0);
                String key;
                int value;
            switch (ch) {
                case 'A' ->
                {
                    System.out.println("Enter the key-value pair you want to add to hash table");
                    key = sc.next();
                    value = sc.nextInt();
                    hashtable.put(key, value);
                    break ;
                }
                case 'B' ->
                {
                    System.out.println("Enter the key-value pair you want to delete");
                    key = sc.next();
                    if (!hashtable.isEmpty()) {
                        if (hashtable.containsKey(key))
                            hashtable.remove(key);
                        else
                            System.out.println("Key not found");
                    } else
                        System.out.println("Hash Table already empty");
                    break ;
                }
                case 'C' ->
                {
                    System.out.println("Enter the key you want to check");
                    key = sc.next();
                    if (hashtable.containsKey(key))
                        System.out.println("Key found");
                    else
                        System.out.println("Key not found");

                    System.out.println("Enter the value you want to search");
                    value = sc.nextInt();
                    if (hashtable.containsValue(value))
                        System.out.println("Value found");
                    else
                        System.out.println("Value not found");
                    break ;

                }
                case 'D' ->
                {
                    System.out.println("Enter the kay whose value you want to get");
                    key = sc.next();
                    if (hashtable.containsKey(key))
                        System.out.println("The value for key " + key + "= " + hashtable.get(key));
                    else
                        System.out.println("Key not found");
                    break ;

                }
                case 'E' ->
                {
//                    iterator
                    Set<String> setOfCountries = hashtable.keySet();
                    for (String k : setOfCountries) {
                        System.out.println(k + "\t" + hashtable.get(k));
                    }
                    break ;
                }
                case 'F' -> {
                    System.out.println("Size of hashtable is : " + hashtable.size());
                    break;
                }
                case 'G' ->
                {
                    System.out.println("The Traversing through the hashtable is :");
                    if (hashtable.size() != 0)
                    {
                        Enumeration<String> keys = hashtable.keys();
                        while (keys.hasMoreElements())
                        {
                            key = keys.nextElement();
                            System.out.println("Key: " + key + ", Value: " + hashtable.get(key));
                        }
                    } else
                        System.out.println("Hash Table is Empty");
                    break ;
                }
                default -> System.out.println("Input a valid choice");
            }
                choice = ' ';
            while(choice != 'Y' && choice != 'N')
            {
                System.out.print("Wish to continue? (Y/N) ? ");
                choice = sc.next().toUpperCase().charAt(0);

                if(choice != 'Y' && choice != 'N')
                {
                    System.out.println("Please input a valid character");
                }
            }
            } while (choice != 'N');

    }
}
class Stack_class{
    static void func(){
        Stack<Integer> stack = new Stack<>();
        Scanner sc = new Scanner(System.in);
        char choice ;
        do {
            System.out.println("""
                    Enter which operation you would like to perform
                    A:Push
                    B:Pop
                    C:Peek
                    D:Contains
                    E:Size
                    F:Sort
                    G:Center
                    H:Reverse
                    I:Iterator
                    J:Traverse\\Print""");
            System.out.println("Input your choice");
            char ch = sc.next().toUpperCase().charAt(0);
            switch (ch) {
                case 'A' ->
                {
                    System.out.println("Input the value to be pushed");
                    stack.push(sc.nextInt());
                    break ;
                }
                case 'B' -> {
                     System.out.println("Element popped : " + stack.pop());
                     break ;
                }
                case 'C' ->
                {
                    System.out.println("Element at top : " + stack.peek());
                    break ;
                }
                case 'D' ->
                {
                    System.out.println("Input value to be searched");
                    Integer pos = (Integer) stack.search(sc.nextInt());
                    if (pos == -1)
                        System.out.println("Element not found");
                    else
                        System.out.println("Element is found at position: " + pos);
                    break ;
                }
                case 'E' ->
                {
                    System.out.println("Size of Stack: " + stack.size());
                    break ;
                }
                case 'F' ->
                {
                    Collections.sort(stack);
                    System.out.println("The sorted stack is here as follows : \n" + stack);
                    break;
                }
                case 'G' ->
                {
                         if (stack.size() == 0)
                         {
                            System.out.println("Stack is empty now");
                           break;
                        }
                         else {
                            System.out.println(stack.remove((stack.size()/2)));
                        }
                       break;

                }
                case 'H' ->
                {
//                reverse
                    System.out.println("Reversed Stack is :");
                    for (int i = 0; i < stack.size(); i++) {
                        System.out.println(stack.pop());
                    }
                    break ;
                }
                case 'I' ->
                {
//              iterator
                    for (Integer integer : stack) {
                        System.out.println(integer);
                    }
                    break ;
                }
                case 'J' ->
                {
//                traverse
                    for (Integer item : stack)
                        System.out.println(item);
                    break ;
                }
                case 'K' ->
                {
                    System.out.println("Exiting Stack Implementation function ");
                    break ;
                }
            }
            choice = ' ';
            while(choice != 'Y' && choice != 'N')
            {
                System.out.print("Wish to continue? (Y/N) ? ");
                choice = sc.next().toUpperCase().charAt(0);

                if(choice != 'Y' && choice != 'N')
                {
                    System.out.println("Please input a valid character");
                }
            }

        }
        while(choice!='N');
    }

}


class Queue{
    static int func(){
        Scanner obj = new Scanner(System.in);
        java.util.Queue<Integer> q= new PriorityQueue<Integer>();
        Iterator<Integer>it1;
        it1 = q.iterator();
        char choice ;
        do {
            System.out.println("""
                    Enter which operation you would be like to perform in queue\s
                    A:Enqueue
                    B:Dequeue(Highest Priority)
                    C:Peek(Highest Priority)
                    D:Contains
                    E:Size
                    F:Centre
                    G:Sort
                    H:Reverse
                    I:Iterator
                    J: Traverse/Print""");
            char ch = obj.next().toUpperCase().charAt(0);
            switch(ch)
            {
                case 'A':
                {
                    System.out.println("Enter the values in the queue");
                    int x = obj.nextInt();
                    q.add(x);
                    break ;
                }
                case 'B':
                {
                    if(q.isEmpty())
                        System.out.println(" Queue is empty.");
                    else
                        System.out.println(q.poll());
                    break;
                }
                case 'C':
                {
                    System.out.println("The top element of Queue is" + q.peek() );
                }
                case 'D':
                {
                    System.out.println("Enter the number user want to check if it is present in the queue");
                    int y = obj.nextInt();
                    System.out.println("Does the  Queue contains " + y + q.contains(y));
                    break ;
                }
                case 'E':
                {
                    System.out.println("The size of the  Queue is: " + q.size());
                    break ;
                }
                case 'F':
                {
                    int indexOfMiddleNumber = q.size() / 2;
                    for (int index = 0; index < indexOfMiddleNumber; ++index) {
                        q.poll();
                    }
                    System.out.println(q.poll());
                    break ;
                }
                case 'G':
                {
                    int n = q.size() ;
                    int[] arr = new int [n];
                    for(int i = 0 ; i<n ; i++)
                        arr[i]=obj.nextInt();
                    Arrays.sort(arr);
                    System.out.println("The sorted queue is as follows :");
                    for(int i = 0 ; i< n ; i++)
                    {
                        System.out.print(arr[i]);
                    }
                     break ;
                }
                case 'H':
                {
                    System.out.println("The reverse queue is hereby as follows :");
                    java.util.Stack<Integer> st = new java.util.Stack<Integer>();
                    while (!q.isEmpty()) {
                        st.add(q.peek());
                        q.remove();
                    }
                    while (!st.isEmpty()) {
                        q.add(st.peek());
                        System.out.print(st.pop());
                    }
                    break ;
                }
                case 'I':
                {
                    System.out.println("The iterator values are: ");
                    while (it1.hasNext()) {
                        System.out.println(it1.next());
                    }
                    System.out.println();
                    break ;
                }
                case 'J':
                {
                    System.out.println("The Traversed elements in  queue are :");
                    while (it1.hasNext())
                    {
                        System.out.println(it1.next());
                    }
                    System.out.println() ;
                    break ;
                }
                default:
                    System.out.println("Input a valid choice");
                    break;
            }
        choice = ' ';
        while(choice != 'Y' && choice != 'N')
        {
            System.out.print("Wish to continue? (Y/N) ? ");
            choice = obj.next().toUpperCase().charAt(0);

            if(choice != 'Y' && choice != 'N')
            {
                System.out.println("Please input a valid character");
            }
        }
    }
    while(choice != 'N');
        return 0;
    }
}
class Priority_Queue {

    static void func() {
        Scanner obj = new Scanner(System.in);
        PriorityQueue<Integer> pq = new PriorityQueue<>(Collections.reverseOrder());
        Iterator<Integer> it = pq.iterator();
        char choice ;
        do {
            System.out.println("""
                     Enter which operation you would be like to perform in priority queue\s
                    A:Enqueue
                    B:Dequeue(Highest Priority)
                    C:Peek(Highest Priority)
                    D:Contains
                    E:Size
                    F:Centre
                    G:Reverse\s
                    H:Iterator\s
                    I:Traverse/Print
                    """);
            char ch = obj.next().toUpperCase().charAt(0);
            switch (ch) {
                case 'A' ->
                {
                    System.out.println("Enter the values in the queue");
                    int x = obj.nextInt();
                    pq.add(x);
                   break ;
                }
                case 'B' ->
                {
                    if (pq.isEmpty())
                        System.out.println("Priority Queue is empty.");
                    else
                        System.out.println(pq.poll());
                    break ;
                }
                case 'C' ->
                {
                    System.out.println("Peek (Highest priority is here as follows :");
                    System.out.println(pq.peek());
                    break ;
                }
                case 'D' ->
                {
                    System.out.println("Enter the number user want to check if it is present in the queue");
                    int y = obj.nextInt();
                    System.out.println("Does the Priority Queue contains " + y + pq.contains(y));
                    break ;
                }
                case 'E' ->
                {
                    System.out.println("The size of the Priority Queue is: " + pq.size());
                    break ;
                }
                case 'F' ->
                {
                    System.out.println("The middle element of Priority queue is here as follows :");
                    int indexOfMiddleNumber = pq.size() / 2;
                    for (int index = 0; index < indexOfMiddleNumber; ++index) {
                        pq.poll();
                    }
                    System.out.println(pq.poll());
                    break ;
                }
                case 'G' ->
                {
                    System.out.println("The reverse priority queue is here as follows :");
                    Object[] arr = pq.toArray();
                    for (Object o : arr) System.out.println(o);
                    break ;
                }
                case 'H' ->
                {
                    System.out.println("The iteration  elements in priority queue are as follows :");
                    while (it.hasNext()) {
                        System.out.print(it.next());
                    }
                    System.out.println();
                    break ;
                }

                case 'I' ->
                {
                    System.out.println("The Traversed elements in priority queue are :");
                    while (it.hasNext()) {
                        System.out.print(it.next());
                    }
                    System.out.println();
                    break ;
                }
                default -> System.out.println("Input a valid choice");
            }
            choice = ' ';
            while(choice != 'Y' && choice != 'N')
            {
                System.out.print("Wish to continue? (Y/N) ? ");
                choice = obj.next().toUpperCase().charAt(0);

                if(choice != 'Y' && choice != 'N')
                {
                    System.out.println("Please input a valid character");
                }
            }
        }while(choice != 'N');
    }
}
class Data_Structure{
    public static void main(String [] args ){
        char ch;
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("""
                    Enter which data structure you want to implement
                    1: Linked List
                    2: Hash_table
                    3: Stack
                    4: Queue
                    5: Priority Queue
                    6:Exit
                    """);
            ch = sc.next().charAt(0);
            switch (ch) {
                case '1' -> Linked_list.func();
                case '2' -> Hash_table.func();
                case '3' -> Stack_class.func();
                case '4' -> Queue.func();
                case '5' -> Priority_Queue.func();
                default -> System.out.println("Please make a valid choice");
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}